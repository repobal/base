# -*- coding: utf-8 -*-

import sys

PY3 = False
if sys.version_info[0] >= 3: PY3 = True

if PY3:
    import xbmcvfs
    translatePath = xbmcvfs.translatePath
else:
    import xbmc
    translatePath = xbmc.translatePath


import os, xbmc, time

from platformcode import config, logger, platformtools
from core import filetools, httptools, scrapertools
from lib import jsunpack


host= 'https://uqload.vc/'


espera = config.get_setting('servers_waiting', default=6)

color_exec = config.get_setting('notification_exec_color', default='cyan')
el_srv = ('Sin respuesta en [B][COLOR %s]') % color_exec
el_srv += ('ResolveUrl[/B][/COLOR]')


def import_libs(module):
    import xbmcaddon

    path = os.path.join(xbmcaddon.Addon(module).getAddonInfo("path"))
    addon_xml = filetools.read(filetools.join(path, "addon.xml"))

    if addon_xml:
        require_addons = scrapertools.find_multiple_matches(addon_xml, '(<import addon="[^"]+"[^\/]+\/>)')
        require_addons = list(filter(lambda x: not 'xbmc.python' in x and 'optional="true"' not in x, require_addons))

        for addon in require_addons:
            addon = scrapertools.find_single_match(addon, 'import addon="([^"]+)"')
            if xbmc.getCondVisibility('System.HasAddon("%s")' % (addon)):
                import_libs(addon)
            else:
                xbmc.executebuiltin('InstallAddon(%s)' % (addon))
                import_libs(addon)

        lib_path = scrapertools.find_multiple_matches(addon_xml, 'library="([^"]+)"')
        for lib in list(filter(lambda x: not '.py' in x, lib_path)):
            sys.path.append(os.path.join(path, lib))


def get_video_url(page_url, url_referer=''):
    logger.info("url=" + page_url)
    video_urls = []

    ini_page_url = page_url

    if not 'embed-' in page_url:
        page_url = page_url.replace('/uqload.com/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.org/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.co/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.io/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.to/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.ws/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.net/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.cx/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.bz/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.is/', '/uqload.com/embed-')
        page_url = page_url.replace('/uqload.vc/', '/uqload.com/embed-')

    if not page_url.endswith('.html'): page_url += '.html'

    page_url = page_url.replace('.html/.html', '.html')

    data = httptools.downloadpage(page_url, headers = {'Referer': host, 'Origin': host}).data

    if 'File was deleted' in data:
        return 'Archivo inexistente ó eliminado'
    elif 'File is no longer available as it expired or has been deleted' in data:
        return 'Archivo inexistente ó eliminado'
    elif 'The file expired' in data or 'The file was deleted' in data:
        return 'Archivo inexistente ó eliminado'

    bloque = scrapertools.find_single_match(data, 'sources\s*:\s*\[(.*?)\]')

    if not bloque:
        unpacked = ''

        try:
            packed = scrapertools.find_single_match(data, "text/javascript'>(eval.*?)\s*</script>")

            if not packed: packed = scrapertools.find_single_match(data, 'p,a,c,k,e,d.*?</script>')

            if packed: unpacked = jsunpack.unpack(packed)
        except:
            pass

        if unpacked:
            bloque = scrapertools.find_single_match(unpacked, 'sources\s*:\s*\[(.*?)\]')

            if not bloque: bloque = scrapertools.find_single_match(unpacked, 'sources:\[\{file:"([^"]+)"')

    matches = scrapertools.find_multiple_matches(bloque, '(http.*?)"')

    for url in matches:
        if '.m3u8' in url: type = 'm3u8'
        elif '.m3u' in url: type = 'm3u8'
        else: type = 'mp4'

        url = url + '|Referer=%s' + host

        video_urls.append(['mp4', url ])

    if not video_urls:
        if xbmc.getCondVisibility('System.HasAddon("script.module.resolveurl")'):
            path = translatePath(os.path.join('special://home/addons/script.module.resolveurl/lib/resolveurl/plugins/', 'uqload.py'))

            existe = filetools.exists(path)
            if not existe:
                return 'El Plugin No existe en Resolveurl'

            if config.get_setting('servers_time', default=True):
                platformtools.dialog_notification('Cargando [COLOR cyan][B]Uqload[/B][/COLOR]', 'Espera requerida de %s segundos' % espera)
                time.sleep(int(espera))

            try:
                import_libs('script.module.resolveurl')

                if xbmc.getCondVisibility('System.HasAddon("script.module.cloudrequest")'):
                    import_libs('script.module.cloudrequest')

                import resolveurl
                page_url = ini_page_url
                resuelto = resolveurl.resolve(page_url)

                if resuelto:
                    if '.m3u8' in resuelto: video_urls.append(['m3u8', resuelto])
                    elif '.m3u' in resuelto: video_urls.append(['m3u', resuelto])
                    elif '.mp4' in resuelto: video_urls.append(['mp4', resuelto])
                    else: video_urls.append(['', resuelto])
                    return video_urls

                color_exec = config.get_setting('notification_exec_color', default='cyan')
                el_srv = ('Sin respuesta en [B][COLOR %s]') % color_exec
                el_srv += ('ResolveUrl[/B][/COLOR]')
                platformtools.dialog_notification(config.__addon_name, el_srv, time=3000)

                page_url = ini_page_url

                return 'No se pudo Reproducir el Vídeo con ResolveUrl'

            except:
                import traceback
                logger.error(traceback.format_exc())

                if 'resolveurl.resolver.ResolverError:' in traceback.format_exc():
                    trace = traceback.format_exc()
                    if 'File Removed' in trace or 'File Not Found or' in trace or 'The requested video was not found' in trace or 'File deleted' in trace or 'No video found' in trace or 'No playable video found' in trace or 'Video cannot be located' in trace or 'file does not exist' in trace or 'Video not found' in trace:
                        return 'Archivo inexistente ó eliminado'

                    elif 'No se ha encontrado ningún link al' in trace or 'Unable to locate link' in trace or 'Video Link Not Found' in trace:
                        return 'Fichero sin link al vídeo ó restringido'

                    elif 'Cloudflare challenge' in trace:
                        return 'Cloudflare Challenge Check'

                elif ' Bad Request' in traceback.format_exc():
                   if '/recaptcha/' in traceback.format_exc(): return 'Fichero de Vídeo con CaptCha'

                elif "No module named 'cloudscraper'" in traceback.format_exc():
                    return 'Falta script.module.cloudrequest'

                elif 'HTTP Error 404: Not Found' in traceback.format_exc() or '404 Not Found' in traceback.format_exc():
                    return 'Archivo inexistente'

                elif '<urlopen error' in traceback.format_exc():
                    return 'No se puede establecer la conexión'

                return 'Sin Respuesta ResolveUrl'

        else:
            return 'Falta ResolveUrl'

    return video_urls
